from zipfile import ZipFile

# Attempt to extract the zip file with a given password
def attempt_extract(zf_handle, password):
    """Try to extract the encrypted ZIP file with the given password."""
    try:
        zf_handle.extractall(pwd=password)
        print(f"[+] Password found: {password.decode()}")
        return True
    except:
        return False

def main():
    print("[+] Beginning brute-force attack...")

    # Open the encrypted ZIP file
    with ZipFile('enc.zip') as zf:
        # Open the Rockyou wordlist
        with open('rockyou.txt', 'rb') as f:
            # Iterate through each password in the wordlist
            for password in f:
                password = password.strip()
                if attempt_extract(zf, password):
                    print("[+] File successfully decrypted!")
                    return

    # If no password matches, print this message
    print("[-] Password not found in the wordlist.")

if __name__ == "__main__":
    main()
